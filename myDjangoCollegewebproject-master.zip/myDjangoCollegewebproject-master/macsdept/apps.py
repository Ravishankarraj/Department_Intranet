from django.apps import AppConfig


class MacsdeptConfig(AppConfig):
    name = 'macsdept'
